The following folders contain PKGBUILD file for arch(like) distro's. You can use those as starting point for your own packages.

Regards,
Minze Zwerver
